﻿namespace Syn.Core.SqlSchemaGenerator.Interfaces
{
    /// <summary>
    /// Marker interface to indicate that a class represents a database entity.
    /// </summary>
    public interface IDbEntity { }
}
